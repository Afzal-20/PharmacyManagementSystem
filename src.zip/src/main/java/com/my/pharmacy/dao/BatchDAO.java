package com.my.pharmacy.dao;

import com.my.pharmacy.model.Batch;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface BatchDAO {
    void addBatch(Batch batch);
    List<Batch> getAllBatches();
    Batch getBatchById(int id);
    List<Batch> getBatchesByProductId(int productId);
    void updateBatch(Batch batch);
    void reduceStock(Connection conn, int batchId, int qty) throws SQLException;
    void adjustStockWithAudit(int batchId, int oldQty, int newQty, String reason, int userId);
    void recordPurchaseHistory(int dealerId, int productId, String productName, String batchNo, String invoiceNo, int boxes, double cost, double trade);
    // --- NEW: Exact Match Duplicate Guard ---
    Batch getExactBatchMatch(int productId, String batchNo, String expiryDate, double costPrice, double tradePrice);
    List<com.my.pharmacy.model.PurchaseHistoryRecord> getPurchaseHistoryByProductId(int productId);
}